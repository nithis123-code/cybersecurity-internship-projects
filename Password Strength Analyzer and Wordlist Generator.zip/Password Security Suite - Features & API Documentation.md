# Password Security Suite - Features & API Documentation

## Overview

This document provides comprehensive documentation of all features, utilities, and APIs available in the Password Security Suite. Developers and security professionals can use this guide to understand the capabilities of each tool and how to integrate them into their workflows.

## Table of Contents

1. [Password Strength Analyzer](#password-strength-analyzer)
2. [Wordlist Generator](#wordlist-generator)
3. [Web App Vulnerability Scanner](#web-app-vulnerability-scanner)
4. [Utility Functions](#utility-functions)
5. [Integration Examples](#integration-examples)

---

## Password Strength Analyzer

### Overview

The Password Strength Analyzer evaluates password security using a comprehensive scoring algorithm that considers multiple security factors including character composition, entropy, pattern detection, and length.

### Core API

#### `analyzePassword(password: string): PasswordStrengthResult`

Analyzes a password and returns detailed security metrics and recommendations.

**Parameters:**
- `password` (string): The password to analyze

**Returns:**
- `PasswordStrengthResult` object containing:
  - `score` (number): Security score from 0-100
  - `strength` (string): Strength level (weak/fair/good/strong)
  - `percentage` (number): Percentage representation of score
  - `feedback` (string[]): Array of improvement suggestions
  - `metrics` (object): Detailed security metrics

**Example Usage:**

```typescript
import { analyzePassword } from '@/lib/passwordAnalyzer';

const result = analyzePassword('MyP@ssw0rd!');
console.log(result.score);        // 85
console.log(result.strength);     // 'good'
console.log(result.feedback);     // ['Add more special characters']
console.log(result.metrics);      // { length: 12, hasUppercase: true, ... }
```

### Metrics Explained

The analyzer evaluates passwords across the following dimensions:

**Length Analysis**: Passwords are scored based on character count, with bonuses for reaching 8, 12, and 16+ character thresholds. Minimum recommended length is 8 characters.

**Character Variety**: The analyzer checks for presence of uppercase letters, lowercase letters, numbers, and special characters. Each character type present increases the score by 10-15 points.

**Pattern Detection**: Sequential characters (abc, 123) and repeating characters (aaa, 111) are detected and penalize the score. These patterns are commonly exploited in dictionary attacks.

**Entropy Calculation**: Shannon entropy is calculated based on the character set size and password length. Higher entropy indicates better randomness and resistance to brute-force attacks.

### Scoring Algorithm

The scoring system uses the following formula:

```
Base Score = 0
Score += 10 for each length threshold (8, 12, 16 chars)
Score += 10 for uppercase letters
Score += 10 for lowercase letters
Score += 10 for numbers
Score += 15 for special characters
Score -= 10 for sequential characters
Score -= 5 for repeating characters
Score += 10 for entropy > 50 bits
Score += 5 for entropy > 80 bits
Final Score = Math.max(0, Math.min(100, Score))
```

### Strength Levels

| Score Range | Strength | Risk Level | Recommendation |
|-------------|----------|-----------|-----------------|
| 0-29 | Weak | Critical | Not suitable for important accounts |
| 30-59 | Fair | High | Acceptable for low-risk accounts only |
| 60-79 | Good | Medium | Suitable for most accounts |
| 80-100 | Strong | Low | Excellent security, recommended |

### Component Usage

The `PasswordAnalyzer` component provides a user-friendly interface:

```typescript
import PasswordAnalyzer from '@/components/PasswordAnalyzer';

export default function MyApp() {
  return <PasswordAnalyzer />;
}
```

### Features

The Password Analyzer component includes:

- Real-time analysis as the user types
- Show/hide password toggle for privacy
- Copy to clipboard functionality
- Visual strength indicators with color coding
- Detailed metrics grid showing character composition
- Actionable improvement suggestions
- Empty state guidance

---

## Wordlist Generator

### Overview

The Wordlist Generator creates custom word lists for security testing, penetration testing, and password cracking scenarios. It supports extensive customization options to generate wordlists tailored to specific testing needs.

### Core API

#### `generateWordlist(options: WordlistOptions): GeneratedWordlist`

Generates a wordlist based on specified options.

**Parameters:**
- `options` (WordlistOptions):
  - `count` (number): Number of words to generate (5-1000)
  - `minLength` (number): Minimum word length (1-20)
  - `maxLength` (number): Maximum word length (1-30)
  - `includeNumbers` (boolean): Append random digit to each word
  - `includeSpecialChars` (boolean): Append random special character
  - `capitalize` (boolean): Capitalize first letter of each word
  - `separator` (string): Separator between words

**Returns:**
- `GeneratedWordlist` object containing:
  - `words` (string[]): Array of generated words
  - `options` (WordlistOptions): The options used for generation
  - `generatedAt` (Date): Timestamp of generation

**Example Usage:**

```typescript
import { generateWordlist, downloadWordlist } from '@/lib/wordlistGenerator';

const wordlist = generateWordlist({
  count: 100,
  minLength: 5,
  maxLength: 10,
  includeNumbers: true,
  includeSpecialChars: false,
  capitalize: true,
  separator: '\n'
});

// Download the wordlist
downloadWordlist(wordlist, 'custom-wordlist.txt');
```

#### `formatWordlist(wordlist: GeneratedWordlist, separator: string): string`

Formats a generated wordlist with custom separators.

**Parameters:**
- `wordlist` (GeneratedWordlist): The wordlist to format
- `separator` (string): Custom separator between words

**Returns:**
- Formatted string with words separated by the specified separator

#### `downloadWordlist(wordlist: GeneratedWordlist, filename: string): void`

Downloads the wordlist as a text file.

**Parameters:**
- `wordlist` (GeneratedWordlist): The wordlist to download
- `filename` (string): Name of the file to download

#### `copyToClipboard(wordlist: GeneratedWordlist, separator: string): Promise<void>`

Copies the wordlist to clipboard with custom separator.

**Parameters:**
- `wordlist` (GeneratedWordlist): The wordlist to copy
- `separator` (string): Separator between words

#### `getWordlistStats(wordlist: GeneratedWordlist): WordlistStats`

Calculates statistics about the generated wordlist.

**Returns:**
- Statistics object containing:
  - `totalWords` (number): Total number of words
  - `totalCharacters` (number): Total character count
  - `averageWordLength` (number): Average length per word
  - `estimatedFileSize` (string): Estimated file size in KB

### Word Database

The generator uses a curated database of 200+ common English words, ensuring generated wordlists are realistic and suitable for security testing. Words are selected from a frequency-based dictionary commonly used in penetration testing.

### Separator Options

| Separator | Use Case | Example Output |
|-----------|----------|-----------------|
| `\n` | File format, one word per line | word1<br>word2<br>word3 |
| `, ` | CSV format, comma-separated | word1, word2, word3 |
| ` ` | Space-separated, readable | word1 word2 word3 |
| `\|` | Pipe-separated, structured | word1\|word2\|word3 |
| `-` | Dash-separated, URL-friendly | word1-word2-word3 |

### Component Usage

The `WordlistGenerator` component provides an interactive interface:

```typescript
import WordlistGenerator from '@/components/WordlistGenerator';

export default function MyApp() {
  return <WordlistGenerator />;
}
```

### Features

The Wordlist Generator component includes:

- Configurable word count slider (5-1000)
- Adjustable minimum and maximum length sliders
- Capitalization toggle
- Number appending toggle
- Special character appending toggle
- Separator selection dropdown
- Real-time statistics display
- Word preview (first 10 words)
- Download functionality
- Clipboard copy with custom separator

---

## Web App Vulnerability Scanner

### Overview

The Web App Vulnerability Scanner identifies common security vulnerabilities in web applications by analyzing URL structure and checking for missing security headers, weak protocols, and configuration issues.

### Core API

#### `scanWebsite(url: string): ScanResult`

Scans a website for vulnerabilities.

**Parameters:**
- `url` (string): Website URL to scan

**Returns:**
- `ScanResult` object containing:
  - `url` (string): The scanned URL
  - `timestamp` (Date): Scan timestamp
  - `vulnerabilities` (Vulnerability[]): Array of detected vulnerabilities
  - `securityScore` (number): Overall security score (0-100)
  - `riskLevel` (string): Risk assessment (critical/high/medium/low/safe)
  - `summary` (object): Count of vulnerabilities by severity

**Example Usage:**

```typescript
import { scanWebsite } from '@/lib/vulnerabilityDetector';

const result = scanWebsite('https://example.com');
console.log(result.securityScore);    // 45
console.log(result.riskLevel);        // 'high'
console.log(result.vulnerabilities);  // [...]
```

#### `analyzeURL(urlString: string): URLAnalysis`

Analyzes URL structure and validity.

**Parameters:**
- `urlString` (string): URL to analyze

**Returns:**
- `URLAnalysis` object containing:
  - `protocol` (string): Protocol (http/https)
  - `domain` (string): Domain name
  - `port` (number): Port number (if specified)
  - `path` (string): URL path
  - `hasSSL` (boolean): Whether HTTPS is used
  - `isValid` (boolean): Whether URL is valid
  - `error` (string): Error message if invalid

### Vulnerability Database

The scanner includes detection for 11+ common vulnerabilities:

| Vulnerability | Severity | CWE | Description |
|---------------|----------|-----|-------------|
| Missing HTTPS | Critical | CWE-295 | No SSL/TLS encryption |
| Missing HSTS | High | CWE-295 | No HTTP Strict Transport Security |
| Missing CSP | High | CWE-79 | No Content Security Policy |
| Missing X-Frame-Options | Medium | CWE-1021 | Page can be embedded in iframes |
| Missing X-Content-Type-Options | Medium | CWE-430 | MIME type sniffing possible |
| Weak TLS | High | CWE-327 | Weak TLS versions or ciphers |
| Missing Referrer-Policy | Low | CWE-200 | Referrer information leaked |
| Missing Permissions-Policy | Low | CWE-1021 | Browser features not restricted |
| Outdated Framework | Medium | CWE-1104 | Potentially outdated dependencies |
| Exposed Headers | Low | CWE-200 | Server information disclosed |
| CORS Misconfiguration | Medium | CWE-346 | Improper cross-origin access control |

### Severity Levels

| Level | Score Impact | Description | Action Required |
|-------|--------------|-------------|-----------------|
| Critical | -25 | Immediate exploitation risk | Fix immediately |
| High | -15 | Significant security risk | Fix within 1 week |
| Medium | -8 | Moderate security concern | Fix within 1 month |
| Low | -3 | Minor security issue | Fix when convenient |
| Info | 0 | Informational only | Monitor and review |

### Security Scoring

The security score is calculated as follows:

```
Base Score = 100
Score -= (Critical count × 25)
Score -= (High count × 15)
Score -= (Medium count × 8)
Score -= (Low count × 3)
Final Score = Math.max(0, Score)
```

### Risk Level Determination

| Risk Level | Criteria | Recommendation |
|-----------|----------|-----------------|
| Safe | No vulnerabilities | Maintain current security posture |
| Low | Only low/info severity issues | Monitor and plan remediation |
| Medium | Medium severity issues present | Schedule remediation within 1 month |
| High | High severity issues present | Prioritize remediation within 1 week |
| Critical | Critical issues present | Immediate remediation required |

### Component Usage

The `VulnerabilityScanner` component provides an interactive scanning interface:

```typescript
import VulnerabilityScanner from '@/components/VulnerabilityScanner';

export default function MyApp() {
  return <VulnerabilityScanner />;
}
```

### Features

The Vulnerability Scanner component includes:

- URL input with validation
- Real-time scanning with progress indicator
- Security score visualization
- Risk level indicator with color coding
- Vulnerability summary statistics
- Detailed vulnerability cards with:
  - Severity badge
  - Description
  - Impact analysis
  - Remediation recommendations
  - CWE references
- Expandable vulnerability details
- Report generation and export
- Scan history tracking

---

## Utility Functions

### Password Analysis Utilities

#### `calculateEntropy(password: string): number`

Calculates Shannon entropy of a password in bits.

**Parameters:**
- `password` (string): Password to analyze

**Returns:**
- Entropy value in bits

#### `hasSequentialChars(password: string): boolean`

Detects sequential character patterns.

**Parameters:**
- `password` (string): Password to check

**Returns:**
- Boolean indicating presence of sequential patterns

#### `hasRepeatingChars(password: string): boolean`

Detects repeating character patterns (3+ consecutive identical characters).

**Parameters:**
- `password` (string): Password to check

**Returns:**
- Boolean indicating presence of repeating patterns

### Wordlist Utilities

#### `capitalizeWord(word: string): string`

Capitalizes the first letter of a word.

**Parameters:**
- `word` (string): Word to capitalize

**Returns:**
- Capitalized word

### Scanner Utilities

#### `getSeverityColor(severity: string): string`

Returns Tailwind CSS classes for severity color coding.

**Parameters:**
- `severity` (string): Severity level

**Returns:**
- CSS class string for text and background color

#### `getSeverityBorder(severity: string): string`

Returns Tailwind CSS classes for severity border styling.

**Parameters:**
- `severity` (string): Severity level

**Returns:**
- CSS class string for border color

---

## Integration Examples

### Example 1: Standalone Password Analyzer

```typescript
import { analyzePassword } from '@/lib/passwordAnalyzer';

function checkPassword(pwd: string) {
  const result = analyzePassword(pwd);
  
  if (result.score < 60) {
    console.warn('Weak password detected');
    console.log('Suggestions:', result.feedback);
  } else {
    console.log('Password is secure');
  }
}

checkPassword('MySecureP@ssw0rd!');
```

### Example 2: Batch Wordlist Generation

```typescript
import { generateWordlist, downloadWordlist } from '@/lib/wordlistGenerator';

function generateMultipleWordlists() {
  const configurations = [
    { count: 100, minLength: 4, maxLength: 8 },
    { count: 500, minLength: 8, maxLength: 12 },
    { count: 1000, minLength: 12, maxLength: 16 }
  ];
  
  configurations.forEach((config, index) => {
    const wordlist = generateWordlist({
      ...config,
      includeNumbers: true,
      capitalize: true,
      separator: '\n'
    });
    
    downloadWordlist(wordlist, `wordlist-${index + 1}.txt`);
  });
}
```

### Example 3: Website Security Assessment

```typescript
import { scanWebsite } from '@/lib/vulnerabilityDetector';

async function assessWebsiteSecurity(urls: string[]) {
  const results = urls.map(url => scanWebsite(url));
  
  const criticalIssues = results.filter(r => r.riskLevel === 'critical');
  
  if (criticalIssues.length > 0) {
    console.error(`Found ${criticalIssues.length} websites with critical vulnerabilities`);
    criticalIssues.forEach(result => {
      console.log(`${result.url}: Score ${result.securityScore}/100`);
    });
  }
}

assessWebsiteSecurity([
  'https://example1.com',
  'https://example2.com',
  'https://example3.com'
]);
```

---

## Performance Considerations

### Password Analysis

Password analysis is performed synchronously and completes in milliseconds. No performance issues expected even with very long passwords.

### Wordlist Generation

Wordlist generation performance depends on the requested word count. Typical performance:

- 100 words: <10ms
- 500 words: 20-50ms
- 1000 words: 50-100ms

For very large wordlists (1000+ words), consider generating in chunks or using web workers for non-blocking generation.

### Vulnerability Scanning

Scanning is performed locally without network requests and completes in 1-2 seconds. Performance is consistent regardless of URL complexity.

---

## Error Handling

All functions include error handling for invalid inputs:

```typescript
try {
  const result = analyzePassword(password);
} catch (error) {
  console.error('Analysis failed:', error.message);
}

try {
  const analysis = analyzeURL(url);
  if (!analysis.isValid) {
    console.error('Invalid URL:', analysis.error);
  }
} catch (error) {
  console.error('URL analysis failed:', error.message);
}
```

---

## Best Practices

### For Password Analysis

1. Always display strength feedback to users
2. Enforce minimum password requirements (8+ characters)
3. Encourage special character usage
4. Warn users about sequential and repeating patterns
5. Never log or store analyzed passwords

### For Wordlist Generation

1. Validate word count before generation
2. Provide progress feedback for large wordlists
3. Offer multiple export formats
4. Include metadata in exported files
5. Warn users about appropriate use cases

### For Vulnerability Scanning

1. Scan regularly as part of security audits
2. Prioritize critical and high-severity issues
3. Implement recommended remediations
4. Track scan results over time
5. Supplement with professional penetration testing

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | March 2026 | Initial release with Password Analyzer, Wordlist Generator, and Vulnerability Scanner |

---

**Last Updated**: March 2026  
**Maintained By**: Manus AI Security Suite Team
