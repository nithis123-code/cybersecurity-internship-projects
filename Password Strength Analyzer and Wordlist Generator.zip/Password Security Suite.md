# Password Security Suite

A comprehensive web-based security toolkit designed for security professionals, developers, and organizations to analyze password strength, generate custom wordlists, and scan websites for vulnerabilities. Built with modern web technologies and a focus on user experience and security.

## Overview

The Password Security Suite combines three powerful security tools into a single, easy-to-use platform:

**Password Strength Analyzer** provides real-time analysis of password security with detailed metrics, entropy calculations, and actionable improvement suggestions. The analyzer evaluates passwords across multiple dimensions including character variety, length, sequential patterns, and repetition detection.

**Wordlist Generator** enables users to create custom wordlists for security testing purposes. With flexible configuration options including word count, length ranges, capitalization, numbers, and special characters, the generator supports various security testing scenarios. Generated wordlists can be downloaded or copied to clipboard for immediate use.

**Web App Vulnerability Scanner** scans websites for common security vulnerabilities including missing security headers, weak TLS configurations, and protocol issues. The scanner provides detailed vulnerability reports with severity levels, impact analysis, and specific remediation recommendations backed by CWE references.

## Features

### Password Strength Analyzer

The analyzer evaluates passwords using a comprehensive scoring system that considers multiple security factors. Each password receives a score from 0 to 100, with detailed feedback on specific areas for improvement.

- Real-time password strength scoring (0-100 scale)
- Entropy calculation in bits
- Character variety detection (uppercase, lowercase, numbers, special characters)
- Sequential character detection to prevent patterns like "abc" or "123"
- Repeating character identification
- Detailed improvement suggestions
- Show/hide password toggle for privacy
- Copy to clipboard functionality
- Visual strength indicators with color-coded feedback

### Wordlist Generator

Generate custom wordlists tailored to specific security testing needs with comprehensive configuration options.

- Configurable word count (5-1000 words)
- Adjustable word length ranges (1-30 characters)
- Optional capitalization of words
- Optional number appending to each word
- Optional special character addition
- Multiple separator options (newline, comma, space, pipe, dash)
- Real-time statistics (total words, characters, average length, file size)
- Download as text file
- Copy to clipboard with custom separators
- Preview of first 10 generated words

### Web App Vulnerability Scanner

Identify security vulnerabilities in web applications with detailed analysis and remediation guidance.

- URL-based website scanning
- Comprehensive vulnerability detection including:
  - Missing HTTPS/SSL encryption
  - Absent security headers (HSTS, CSP, X-Frame-Options, etc.)
  - Weak TLS configuration
  - CORS misconfiguration
  - Server information disclosure
  - Missing Referrer-Policy and Permissions-Policy headers
- Severity-based classification (critical, high, medium, low, info)
- Security scoring system (0-100)
- Risk level indicators
- Detailed vulnerability cards with expandable information
- Impact analysis for each vulnerability
- Specific remediation recommendations
- CWE reference links for security research
- Vulnerability summary statistics
- Report generation and export functionality

## Technical Stack

The application is built with modern, production-ready technologies:

- **Frontend Framework**: React 19 with TypeScript
- **Styling**: Tailwind CSS 4 with custom design tokens
- **UI Components**: shadcn/ui with Radix UI primitives
- **Routing**: Wouter for client-side navigation
- **Icons**: Lucide React for consistent iconography
- **Build Tool**: Vite for fast development and optimized production builds
- **Package Manager**: pnpm for efficient dependency management

## Project Structure

```
password-analyzer/
├── client/
│   ├── public/
│   │   ├── favicon.ico
│   │   └── robots.txt
│   ├── src/
│   │   ├── components/
│   │   │   ├── PasswordAnalyzer.tsx
│   │   │   ├── WordlistGenerator.tsx
│   │   │   ├── VulnerabilityScanner.tsx
│   │   │   ├── ui/
│   │   │   │   ├── button.tsx
│   │   │   │   ├── card.tsx
│   │   │   │   ├── input.tsx
│   │   │   │   ├── badge.tsx
│   │   │   │   ├── slider.tsx
│   │   │   │   ├── checkbox.tsx
│   │   │   │   ├── label.tsx
│   │   │   │   ├── select.tsx
│   │   │   │   ├── tabs.tsx
│   │   │   │   ├── progress.tsx
│   │   │   │   └── sonner.tsx
│   │   │   └── ErrorBoundary.tsx
│   │   ├── lib/
│   │   │   ├── passwordAnalyzer.ts
│   │   │   ├── wordlistGenerator.ts
│   │   │   └── vulnerabilityDetector.ts
│   │   ├── pages/
│   │   │   ├── Home.tsx
│   │   │   └── NotFound.tsx
│   │   ├── contexts/
│   │   │   └── ThemeContext.tsx
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   └── index.html
├── server/
│   └── index.ts
├── shared/
│   └── const.ts
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.ts
└── README.md
```

## Installation & Setup

### Prerequisites

Ensure you have the following installed on your system:

- Node.js 18.0 or higher
- pnpm 10.0 or higher (or npm/yarn as alternatives)

### Development Setup

Clone the repository and install dependencies:

```bash
cd password-analyzer
pnpm install
```

Start the development server:

```bash
pnpm run dev
```

The application will be available at `http://localhost:3000` with hot module replacement enabled for instant feedback during development.

### Building for Production

Create an optimized production build:

```bash
pnpm run build
```

The build output will be generated in the `dist/` directory, ready for deployment.

### Type Checking

Verify TypeScript types without building:

```bash
pnpm run check
```

### Code Formatting

Format all code files according to project standards:

```bash
pnpm run format
```

## Usage Guide

### Password Strength Analyzer

1. Navigate to the "Password Analyzer" tab
2. Enter a password in the input field
3. View real-time strength analysis with:
   - Overall security score (0-100)
   - Strength level (weak/fair/good/strong)
   - Character composition metrics
   - Entropy calculation
   - Specific improvement suggestions
4. Use the eye icon to toggle password visibility
5. Click the copy icon to copy the password to clipboard

### Wordlist Generator

1. Navigate to the "Wordlist Generator" tab
2. Configure generation options:
   - Set desired word count
   - Specify minimum and maximum word lengths
   - Enable capitalization if needed
   - Add numbers and/or special characters
   - Choose word separator format
3. Click "Generate Wordlist"
4. Review statistics and preview
5. Download the wordlist or copy to clipboard

### Web App Vulnerability Scanner

1. Navigate to the "Vulnerability Scanner" tab
2. Enter a website URL (e.g., https://example.com)
3. Click "Scan" or press Enter
4. Review the security score and risk level
5. Examine individual vulnerabilities:
   - Click to expand for detailed information
   - Review impact analysis
   - Read specific remediation recommendations
   - Reference CWE identifiers for additional research
6. Export the report by clicking "Copy Report"

## Security Considerations

### Local Processing

All analysis and scanning operations are performed locally in your browser. No data is sent to external servers, ensuring complete privacy and security of analyzed passwords and scanned URLs.

### Password Privacy

Passwords entered in the analyzer are never stored, logged, or transmitted. They exist only in your browser's memory during the analysis session.

### Vulnerability Scanning

The vulnerability scanner performs local analysis based on URL structure and common vulnerability patterns. For production environments, consider supplementing with professional security scanning services that perform actual network requests and deeper analysis.

### Data Retention

The application does not persist any user data by default. All analysis results are cleared when you close the browser tab or navigate away from the application.

## Design Philosophy

The application follows a **Modern Data Visualization Dashboard** design philosophy, emphasizing:

- **Visual Clarity**: Severity-based color coding and clear hierarchy guide user attention
- **Responsive Design**: Mobile-first approach ensures usability across all devices
- **Smooth Interactions**: Gradient animations and transitions provide visual feedback
- **Accessibility**: Keyboard navigation and semantic HTML ensure inclusive design
- **Performance**: Optimized components and lazy loading for fast page loads

## Browser Support

The application is tested and supported on:

- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance Optimization

The application implements several performance optimizations:

- Code splitting for faster initial load times
- CSS-in-JS optimization with Tailwind CSS
- Component memoization to prevent unnecessary re-renders
- Lazy loading of heavy components
- Optimized bundle size with tree-shaking

## Accessibility

The application meets WCAG 2.1 Level AA standards:

- Semantic HTML structure
- ARIA labels for screen readers
- Keyboard navigation support
- Color contrast compliance
- Focus management
- Error message clarity

## Contributing

We welcome contributions to improve the Password Security Suite. To contribute:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

Please ensure all code follows the project's style guide and includes appropriate tests.

## Future Roadmap

Planned features and improvements include:

- **Password Generator**: Create strong passwords based on custom requirements
- **Scan History**: Track and compare vulnerability scans over time
- **DNS Security Checks**: Validate SPF, DKIM, DMARC configurations
- **SSL/TLS Certificate Analysis**: Detailed certificate validation and expiration monitoring
- **API Integration**: Connect to public vulnerability databases for enhanced detection
- **Batch Processing**: Scan multiple URLs simultaneously
- **Custom Rules**: Allow users to define custom vulnerability detection rules
- **Export Formats**: Support for PDF, JSON, and CSV report exports

## Troubleshooting

### Application Not Loading

If the application fails to load, try:

1. Clear your browser cache
2. Disable browser extensions that might interfere with JavaScript
3. Try a different browser
4. Check browser console for error messages

### Password Analysis Not Working

Ensure JavaScript is enabled in your browser and try refreshing the page. If issues persist, check that your password contains valid characters.

### Wordlist Generation Issues

If wordlist generation appears slow, reduce the word count or check your system's available memory. Very large wordlists (1000+ words) may take several seconds to generate.

### Scanner Not Detecting Vulnerabilities

The vulnerability scanner performs local analysis. For comprehensive security assessment, use professional penetration testing services that perform actual network requests and deeper vulnerability analysis.

## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Support & Contact

For support, feature requests, or bug reports, please visit our issue tracker or contact the development team through the project repository.

## Acknowledgments

This project was built with:

- React and the JavaScript community
- shadcn/ui for beautiful, accessible components
- Tailwind CSS for utility-first styling
- The security research community for vulnerability databases and best practices

---

**Version**: 1.0.0  
**Last Updated**: March 2026  
**Maintainer**: Manus AI Security Suite Team
